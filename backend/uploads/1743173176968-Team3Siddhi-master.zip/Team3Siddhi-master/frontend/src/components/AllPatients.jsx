import React ,{useEffect, useState} from "react";
import DataTable from 'react-data-table-component';
import AxiosInstance from "./Axios/Axios";
export default function AllPatients({doctor}) {
    const [rows,setRows] =useState([]);
    useEffect(()=>{
        
        async function getAllpatients(){
            AxiosInstance
            .get(`all_patients_doctor/${doctor}`)
            .then((response) => {
                   let arr = response.data;
                   arr.forEach((element,i) => {
                         element.ID = i+1;
                   });
                   setRows(response.data);
                console.log(response);
            })
            .catch((error) => {
                console.error("Error fetching patient info:", error);
            });
        }
        getAllpatients();
    },[])
    const columns = [
        {
            name: "Patient Name",
            selector: (row) => row.patientName,
            sortable: true,
        },
       
        {
            name: "Ward",
            selector: (row) => row.ward,
            sortable: true,
        },
        {
            name: "Bed No.",
            selector: (row) => row.bed,
            sortable: true,
        },
        
       
    ];

    
    const [search, setSearch] = useState(rows);
    const conditionalRowStyles = [
        {
          when: row => row.ID %2 === 0,
          style: {
            
            backgroundColor: '#2c5282',
            color: '#ffffff',
            
          },
         
        },
        // You can also pass a callback to style for additional customization
        {
            when: row => row.ID %2 === 1,
            style: {
              
              backgroundColor: '#ebf8ff',
              color: '#000000',
              
            },
           
        }
      ];
     
    return (
        <div className="container mt-1 min-w-screen">
            <input
                type="search"
                className="w-full border border-grey-400 rounded-xl p-2 hover:border-blue-700 focus:border-grey-100 appearance-none cursor-pointer max-h-16"
                placeholder="Search"
            />
            <DataTable
                columns={columns}
                data={rows}
                pagination
                selectableRows
                fixedHeader
                title="All Patients"
                conditionalRowStyles={conditionalRowStyles}
                
            />
        </div>
    )
}