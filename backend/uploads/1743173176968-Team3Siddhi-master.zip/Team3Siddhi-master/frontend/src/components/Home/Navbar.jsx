import React, { useState, useEffect, useContext, useRef } from "react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faBars, faXmark } from "@fortawesome/free-solid-svg-icons";
import { Link, NavLink, useNavigate } from "react-router-dom";
import img1 from "./img/logo.png";
import img2 from "./img/img3.jpg";
import "./Home.css";
import AuthContext from "../../../Auth_contxt/Authcontext";
import axios from "axios"; // Import axios for API calls
import AxiosInstance from "../Axios/Axios";
import charakLogo from "../../assets/charak_square_bg.png";
import {
  Avatar,
  Drawer,
  DrawerBody,
  DrawerFooter,
  DrawerHeader,
  DrawerOverlay,
  DrawerContent,
  DrawerCloseButton,
  useDisclosure,
  Input, Button
} from '@chakra-ui/react'

// Component for displaying user details in a popup
const UserDetailsPopup = ({ user, onClose }) => {
  const [profileImage, setProfileImage] = useState(null);

  // Fetch profile image when user changes
  useEffect(() => {
    const fetchProfileImage = async () => {
      try {
        const response = await AxiosInstance.get(
          `profiles/${user.username}/`
        );
        setProfileImage(response.data.image);
      } catch (error) {
        console.error("Error fetching profile image:", error);
      }
    };

    if (user) {
      fetchProfileImage();
    }
  }, []);

  // Handle user logout
  const handleLogout = () => {
    logoutUser();
    navigate("/login");
  };
  const baseUrl =
    import.meta.env.MODE === 'production'
      ? import.meta.env.VITE_API_BASE_URL_PROD_IMG
      : import.meta.env.VITE_API_BASE_URL_LOCAL_IMG;

  return (
    <div className="absolute right-0 mt-2 w-96 p-6 bg-white border rounded-lg shadow-lg z-30">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-xl font-bold text-gray-800">User Details</h2>
        <button
          onClick={onClose}
          className="text-gray-600 hover:text-gray-900 transition duration-300"
        >
          <FontAwesomeIcon icon={faXmark} className="h-6" />
        </button>
      </div>

      <div className="mb-6 text-center">
        <img
          src={profileImage ? `${baseUrl}${profileImage}` : img2}
          alt="User"
          className="object-cover w-32 h-32 border-4 border-gray-200 rounded-full mx-auto shadow-lg"
        />
      </div>
      <div className="text-center mb-6">
        <Link
          to={`/profile/${user.username}`}
          className="text-blue-600 hover:underline text-lg font-medium"
        >
          {user.username}
        </Link>
        <p className="text-gray-500 mt-2">{user.email}</p>
      </div>
      <div className="text-center">
        <button
          onClick={handleLogout}
          className="w-full py-2 px-4 bg-blue-600 text-white font-semibold rounded-lg shadow-md hover:bg-blue-700 transition duration-300"
        >
          Logout
        </button>
      </div>
    </div>
  );
};

// Navbar component
const Navbar = () => {

  const { user, logoutUser } = useContext(AuthContext);
  const navigate = useNavigate();
  const userRef = useRef(null);
  const [profileImage, setProfileImage] = useState(null); // State to store profile image URL
  const { isOpen, onOpen, onClose } = useDisclosure()
  const btnRef = React.useRef()
  // Fetch profile image when user changes
  useEffect(() => {
    const fetchProfileImage = async () => {
      try {
        const response = await AxiosInstance.get(
          `profiles/${user.username}/`
        );
        setProfileImage(response.data.image);
      } catch (error) {
        console.error("Error fetching profile image:", error);
        // Handle error fetching profile image
      }
    };
    console.log(user);
    if (user) {
      fetchProfileImage();
    }
  }, []);

  // Toggle the menu open/close state
  const handleMenu = () => {
    setMenuOpen(!isMenuOpen);
  };

  // Toggle the popup open/close state
  const togglePopup = () => {
    setPopupOpen(!isPopupOpen);
  };

  // Handle user logout
  const handleLogout = () => {
    logoutUser();
    navigate("/login");
  };

  const baseUrl =
    import.meta.env.MODE === 'production'
      ? import.meta.env.VITE_API_BASE_URL_PROD_IMG
      : import.meta.env.VITE_API_BASE_URL_LOCAL_IMG;

  return (



    <>
      <Drawer
        isOpen={isOpen}
        placement='right'
        onClose={onClose}
        finalFocusRef={btnRef}
      >
        <DrawerOverlay />
        <DrawerContent>
          <DrawerCloseButton />
          <DrawerHeader>Charak Center</DrawerHeader>

          <DrawerBody>
            <div class=" w-full h-screen" id="navbar-default">
              <ul class="font-medium flex flex-col gap-4 p-4  mt-4 border border-gray-100 rounded-lg bg-gray-50 md:flex-row md:space-x-8 rtl:space-x-reverse md:mt-0 md:border-0 md:bg-white">
                <li>
                  <a href="/" class="block text-gray-900 hover:text-blue-700 rounded relative text-md w-fit  after:block after:content-[''] after:absolute after:h-[3px] after:bg-blue-700 after:w-full after:scale-x-0 after:hover:scale-x-100 after:transition after:duration-300 after:origin-left">Home</a>
                </li>
                <li>
                  <a href="/PRecords" class="block text-gray-900 hover:text-blue-700 rounded relative text-md w-fit  after:block after:content-[''] after:absolute after:h-[3px] after:bg-blue-700 after:w-full after:scale-x-0 after:hover:scale-x-100 after:transition after:duration-300 after:origin-left">Records</a>
                </li>


                {user ? <Avatar name="vasus" size="sm" /> : <> <Link to="/login">
                  <button className="bg-blue-700 hover:bg-blue-300 rounded px-2 py-1 mb-1 text-white hover:text-blue-700 ">Login</button></Link>
                  <Link to="/register">
                    <button className="bg-blue-700 hover:bg-blue-300 rounded px-2 py-1 mb-1 text-white hover:text-blue-700">SignUp</button>
                  </Link>
                </>}
              </ul>
            </div>
          </DrawerBody>


        </DrawerContent>
      </Drawer>



      <nav class="bg-white border-gray-200 shadow-sm">
        <div class="max-w-screen-xl flex flex-wrap items-center justify-between mx-auto p-4">
          <button
            ref={btnRef}
            onClick={onOpen}
            data-collapse-toggle="navbar-dropdown" type="button" class="inline-flex items-center p-2 w-10 h-10 justify-center text-sm text-gray-500 rounded-lg md:hidden hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-gray-200" aria-controls="navbar-dropdown" aria-expanded="false">
            <span class="sr-only">Open main menu</span>
            <svg class="w-5 h-5" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 17 14">
              <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M1 1h15M1 7h15M1 13h15" />
            </svg>
          </button>
          <a href="#" class="flex items-center space-x-3 rtl:space-x-reverse">
            <img src={charakLogo} class="h-8" alt="Flowbite Logo" />
            <span class="self-center text-2xl font-semibold whitespace-nowrap dark:text-white">Patient Health Monitor</span>
          </a>

          <div class="hidden w-full md:block md:w-auto" id="navbar-dropdown">
            <ul class="flex flex-col font-medium p-4 md:p-0 mt-4 border border-gray-100 rounded-lg bg-gray-50 md:space-x-8 rtl:space-x-reverse md:flex-row md:mt-0 md:border-0 md:bg-white">
              <li>
                <a href="/" class="block py-2 px-3 text-white bg-blue-700 rounded md:bg-transparent md:text-blue-700 md:p-0 md:dark:text-blue-500 dark:bg-blue-600 md:dark:bg-transparent" aria-current="page">Home</a>
              </li>
              <li>
              </li>
              <li>
                <a href="/PRecords" class="block py-2 px-3 text-gray-900 rounded hover:bg-gray-100 md:hover:bg-transparent md:border-0 md:hover:text-blue-700 md:p-0">Records</a>
              </li>

              {user ? (
                <Link to={`/profile/${user.username}`}>
                  <Avatar name={user.username} size="sm" />
                </Link>
              ) : (
                <>
                  <Link to="/login">
                    <button className="bg-blue-700 hover:bg-blue-300 rounded px-2 py-1 mb-1 text-white hover:text-blue-700">Login</button>
                  </Link>
                  <Link to="/register">
                    <button className="bg-blue-700 hover:bg-blue-300 rounded px-2 py-1 mb-1 text-white hover:text-blue-700">SignUp</button>
                  </Link>
                </>
              )}
            </ul>
          </div>
        </div>
      </nav>

    </>

  );
};
export default Navbar;