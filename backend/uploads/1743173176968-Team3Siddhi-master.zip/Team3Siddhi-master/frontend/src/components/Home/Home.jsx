import React from "react";
import Navbar from "./Navbar";
import "./Home.css";
import Footer from "../Footer";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faUpRightFromSquare } from "@fortawesome/free-solid-svg-icons";
import { useNavigate } from "react-router-dom";
import ImgCol from "./ImgCol";
import doctor2 from "../../assets/doctor2.png";
import { Heading,Text } from "@chakra-ui/react";

const Home = () => {
  const navigate = useNavigate();
  return (
    <>
    <div className="font-roboto flex flex-col  home_page bg-gray-50 text-gray-700 h-full w-full">
   <Navbar/>
  <div className="grid grid-cols-3 md:grid-cols-6 h-full w-full">
    <div className="col-span-3 md:col-span-2 flex flex-wrap mt-9 ml-12 items-center text-center justify-center">
      <div className="flex flex-wrap text-center align-center justify-center relative">
      <Heading color="blue.700" zIndex="4">Welcome to Patient Health Monitor.</Heading>
      <Text mt="3" zIndex="4">Our app digitizes patient vitals and uses AI to predict illnesses in real-time, reducing reliance on error-prone nurse charts. By automating diagnosis and storing data securely, it streamlines patient care and eases doctors' workloads. This innovative solution ensures faster, more accurate healthcare. Experience seamless integration for improved patient outcomes.

</Text>
      <button onClick={()=>{
         navigate("/PRecords");
      }} className="bg-blue-950 hover:bg-blue-400 p-3 rounded-xl text-white hover:text-blue-950 mt-3 z-20">Click Here for Patient details</button>
      </div>
      <div className="bg-blue-100 absolute h-[55%] md:h-[61%] w-[50%] top-[10%] left-0 z-2 rounded-tr-full rounded-br-full"></div>
    </div>
   
    <div className="md:col-start-4 col-span-3 md:col-span-3 mt-10 h-full w-full mb-5 z-40">
      <div className="w-full h-full z-40">
        <img src={doctor2} height="90%" width="100%" />
      </div>
    </div>
   
  </div>
  
    </div>
    
    <Footer />
   
    </>
  );
};

export default Home;
