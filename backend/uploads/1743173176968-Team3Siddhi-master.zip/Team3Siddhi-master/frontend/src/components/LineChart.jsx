import React from "react";
import {Chart} from "apexcharts"
export default function LineChart(){
    const series = [
        {
          name: "Height in feet",
          data: [2722, 2080, 2063, 1972, 1516],
        },
      ];
      const options = {
        chart: {
          id: "simple-bar",
        },
        xaxis: {
          categories: [
            "Burj Khalifa",
            "Tokyo Sky Tree",
            "KVLY-TV mast",
            "Abraj Al-Bait Towers",
            "Bren Tower",
          ],
        },
        maintainAspectRatio: false,
      };
      
      return (
        <div>
          <Chart options={options} type="bar" series={series} width="80%" />
        </div>
      );
}