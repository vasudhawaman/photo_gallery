import React, { useEffect, useState } from "react";
import Navbar from "./Home/Navbar";
import {
    Popover,
    PopoverTrigger,
    PopoverContent,
    PopoverHeader,
    PopoverBody,
    PopoverFooter,
    PopoverArrow,
    PopoverCloseButton,
    PopoverAnchor,
    Modal,
    ModalOverlay,
    ModalContent,
    ModalHeader,
    ModalFooter,
    ModalBody,
    ModalCloseButton,
    useDisclosure,
    Button,
    Accordion,
    AccordionItem,
    AccordionButton,
    AccordionPanel,
    AccordionIcon, Text, Box, Flex, Badge, Heading
} from '@chakra-ui/react';
import Tabular from "./Tabular";
import {
    HeartIcon,
    ChartBarIcon,
    ShieldCheckIcon,
    LifebuoyIcon,
    FingerPrintIcon,
} from "@heroicons/react/24/outline";
import { useParams } from "react-router-dom";
import AxiosInstance from "./Axios/Axios";
import TableForUse from "./TableForUse";
import AllPatients from "./AllPatients";
export default function DoctorProfilePage() {
    const {doctor} = useParams();
    const [doctorRecord,setDoctorRecord] = useState(null);
    useEffect(() => {
        // Fetch patient information when patientId changes
        if (doctor) {
            console.log("doctor", doctor);
            AxiosInstance
                .get(`profiles/${doctor}`)
                .then((response) => {
                    
                    console.log(response);
                })
                .catch((error) => {
                    console.error("Error fetching patient info:", error);
                });
               
        }
    }, []);
    return (
        <>
            <Navbar />
            <div className="p-2 w-full">

                <Flex wrap="wrap" w="100%" justifyContent="start" gap="5px" mt="3px">
                    {/* Left box for patient details */}
                    <Box h='100%' w="100%" bg='white' borderWidth='1px' borderRadius='lg' p={2} boxShadow='md' _hover={{ boxShadow: "outline", borderColor: "blue.700", borderRadius: "5px" }}>

                        <Badge borderRadius='full' px='2' colorScheme='blue'>
                           Doctor Details
                        </Badge>

                        <Flex w="100%" p={1}>
                            <div>
                                <Box>

                                </Box>
                                <Heading size={8} mt={1} mb={1} > Doctor Name: {doctor}</Heading>  
                            </div>

                        </Flex>
                    </Box>
                   
                </Flex>
                <Flex w="100%" mt="10px" h="80%" boxShadow='md' p="3" _hover={{ boxShadow: "outline", borderColor: "blue.700", borderRadius: "5px" }}>
                    <AllPatients doctor={doctor} />
                </Flex>


            </div>
        </>
    )
}