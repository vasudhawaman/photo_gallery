import React from "react";
import { Tabs, TabList, TabPanels, Tab, TabPanel,Box } from '@chakra-ui/react'
import TableForUse from "./TableForUse";
import HeartRateChart from "./Home/Heart";
import BloodPressureChart from "./Home/Blood";
import Spo2Chart from "./Home/Spo2";
import TempChart from "./Home/Temp";
import RespRateChart from "./Home/RespRate";

export default function Tabular({patientId}){
  
     return(
      <div className="w-screen p-3 shadow-md border-2 rounded-lg hover:border-blue-400">
     
        <Tabs variant='soft-rounded' colorScheme='blue' p="3px" w="100%">
        <TabList  flexDirection={{ base: "column", sm: "row" }}  // Column on mobile, row on larger screens
          alignItems="center"
          justifyContent="space-around"
          mb={4}>
          <Tab >All Records </Tab>
          <Tab>Heart Rate</Tab>
          <Tab>SpO2 </Tab>
          <Tab>Temperature</Tab>
          <Tab>RespirationRate</Tab>
        </TabList>
        <TabPanels w="100%" >
          <TabPanel>
          <TableForUse patientId={patientId}/>
          </TabPanel>
          <TabPanel>
          <HeartRateChart patientId={patientId} />
          </TabPanel>
          <TabPanel>
          <Spo2Chart patientId={patientId} />
          </TabPanel>
          <TabPanel>
          <TempChart patientId={patientId} />
          </TabPanel>
          <TabPanel>
          <RespRateChart patientId={patientId} />
          </TabPanel>
        </TabPanels>
      </Tabs>
    
      </div>
        
     )
}