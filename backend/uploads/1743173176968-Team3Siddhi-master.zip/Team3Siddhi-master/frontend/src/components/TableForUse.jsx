import React ,{useEffect, useState} from "react";
import DataTable from 'react-data-table-component';
import AxiosInstance from "./Axios/Axios";
export default function TableForUse({patientId}) {
    const [rows,setRows] =useState([]);
    useEffect(()=>{
        
        async function getPreviousVitals(){
            AxiosInstance
            .get(`all_vitals/${patientId}`)
            .then((response) => {
                   let arr = response.data;
                   arr.forEach((element,i) => {
                         element.ID = i+1;
                   });
                   setRows(response.data);
                console.log(response);
            })
            .catch((error) => {
                console.error("Error fetching patient info:", error);
            });
        }
        getPreviousVitals();
    },[])
    const columns = [
        {
            name: "Date",
            selector: (row) => row.appointmentDate,
            sortable: true,
        },
       
        {
            name: "Time",
            selector: (row) => row.appointmentTime,
            sortable: true,
        },
        {
            name: "Respiration",
            selector: (row) => row.respRate,
            sortable: true,
        },
        
        {
            name: "Heart Rate",
            selector: (row) => row.heartRate,
            sortable: true,
        },
        {
            name: "DiastolicBP",
            selector: (row) => row.diastolicBP,
            sortable: true,
        },
        {
            name: "SystolicBP",
            selector: (row) => row.systolicBP,
            sortable: true,
        },
        {
            name: "SpO2",
            selector: (row) => row.spo2Value,
            sortable: true,
        },
        {
            name: "Medication",
            selector: (row) => row.medication,
            sortable: true,
        },
        {
            name: "Body Temperature",
            selector: (row) => row.bodyTemp,
            sortable: true,
        },
    ];

    
    const [search, setSearch] = useState(rows);
    const conditionalRowStyles = [
        {
          when: row => row.ID %2 === 0,
          style: {
            
            backgroundColor: '#2c5282',
            color: '#ffffff',
            
          },
         
        },
        // You can also pass a callback to style for additional customization
        {
            when: row => row.ID %2 === 1,
            style: {
              
              backgroundColor: '#ebf8ff',
              color: '#000000',
              
            },
            
        }
      ];
     
    return (
        <div className="container mt-1 min-w-screen">
            <input
                type="search"
                className="w-full border border-grey-400 rounded-xl p-2 hover:border-blue-700 focus:border-grey-100 appearance-none cursor-pointer max-h-16"
                placeholder="Search"
            />
            <DataTable
                columns={columns}
                data={rows}
                pagination
                selectableRows
                fixedHeader
                title="Previous Records"
                conditionalRowStyles={conditionalRowStyles}
                
            />
        </div>
    )
}