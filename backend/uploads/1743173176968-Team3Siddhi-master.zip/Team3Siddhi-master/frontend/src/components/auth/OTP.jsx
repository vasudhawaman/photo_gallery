import React, { useState, useContext, useEffect } from "react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import Navbar from "../Home/Navbar";
import { faUser, faLock, faEye, faEyeSlash } from "@fortawesome/free-solid-svg-icons";
import { Link, useLocation } from "react-router-dom";
import doctorImage from "./img/logo.png";
import "./Auth.css";
import "./CustomSwal.css";
import AuthContext from "../../../Auth_contxt/Authcontext"; // Import AuthContext for authentication
import Swal from "sweetalert2"; // Import Swal for notifications

const OTP = ({role,username,email,password,otp,setOtp}) => {
  const [typedOTP,setTyped] = useState("")
  const { registerUser } = useContext(AuthContext);
  const [start,setStart] = useState(false);
  const [timeRemaining, setTimeRemaining] = useState(30);
  async function sendOTP(){
    console.log(username,email)
    const formdata = new FormData();
    formdata.append("username",username);
    formdata.append("email",email);
    const userResponse = await AxiosInstance.post(`otp/`,formdata,
      {
        headers: { 'Content-Type': 'multipart/form-data' }
      }
    );
     if (userResponse.status === 200) {
       console.log(userResponse.data);
        setOtp(userResponse.data.otp);
       
     }
  }

  useEffect(() => {
    const timerInterval = setInterval(() => {
      setTimeRemaining((prevTime) => {
        if (prevTime === 0) {
          clearInterval(timerInterval);
          // Perform actions when the timer reaches zero
          console.log('Countdown complete!');
          return 0;
        } else {
          return prevTime - 1;
        }
      });
    }, 1000);

    // Cleanup the interval when the component unmounts
    return () => clearInterval(timerInterval);
  }, []);
  const minutes = Math.floor((timeRemaining % 3600) / 60);
  const seconds = timeRemaining % 60;
  const handleOTP = (e) => {
    e.preventDefault(); // Prevent default form submission
    console.log(String(otp),typedOTP);
    if (typedOTP !== String(otp)) {
        Swal.fire({
          icon: "error",
          title: "OTP MISMATCH",
          text: "OTP IS INCORRECT",
          position: 'top-right',
          timer: 3000,
          customClass: {
            popup: 'my-swal'
          }
        });
      }else{
        registerUser(email, username, role, password, password);
      }
    
    
    
  };

  

  return (

    <div className="flex flex-col font-roboto bg-blue-700">
      <Navbar/>
      <div className="flex flex-col justify-center it ems-center backdrop-filter backdrop-blur-xl border-opacity-30 shadow-lg m-auto p-7 w-full sm:w-4/5 md:w-4/6 lg:w-2/5 border-2 rounded-3xl bg-white  max-w-72 sm:max-w-none">
        <div className="font-bold text-4xl  mb-3 mt-2">Sign Up</div>
        
        <form onSubmit={handleOTP}>
          <div className="flex flex-col gap-4 mt-8">
            <div className="flex flex-col w-full">
              <label htmlFor="use_id" className="text-lg font-bold text-gray-900 mb-1">Enter the otp provided at {email}</label>
              <div className="flex items-center border-2 bg-slate-100 bg-opacity-10 backdrop-filter backdrop-blur-xl shadow-2xl rounded-lg p-2">
                <input
                  id="use_id"
                  type="text"
                  name="otp"
                  placeholder="Enter OTP"
                  className="placeholder-black placeholder:font-medium placeholder:text-sm font-medium text-md w-full bg-transparent bg-opacity-10"
                  value={typedOTP}
                  onChange={(e) => setTyped(e.target.value)} // Update username state on change
                />
              
              </div>
              
            </div>
            <button
              className="bg-blue-700 rounded-lg font-black h-10 text-slate-200"
              type="submit"
            >
             Sign Up
            </button>
           {seconds >0 ? <div className="margin-l-auto">{`${minutes}:${seconds}`}</div>
              :<Link onClick={sendOTP}>Resend OTP?</Link> }
            
          </div>
        </form>
      </div>
    </div>
  );
};

export default OTP;