import React, { useEffect, useState } from "react";
import Navbar from "./Home/Navbar";
import {
    Popover,
    PopoverTrigger,
    PopoverContent,
    PopoverHeader,
    PopoverBody,
    PopoverFooter,
    PopoverArrow,
    PopoverCloseButton,
    PopoverAnchor,
    Modal,
    ModalOverlay,
    ModalContent,
    ModalHeader,
    ModalFooter,
    ModalBody,
    ModalCloseButton,
    useDisclosure,
    Button,
    Accordion,
    AccordionItem,
    AccordionButton,
    AccordionPanel,
    AccordionIcon, Text, Box, Flex, Badge, Heading
} from '@chakra-ui/react';
import Tabular from "./Tabular";
import {
    HeartIcon,
    ChartBarIcon,
    ShieldCheckIcon,
    LifebuoyIcon,
    FingerPrintIcon,
} from "@heroicons/react/24/outline";
import { useNavigate, useParams } from "react-router-dom";
import AxiosInstance from "./Axios/Axios";
export default function PatientProfilePage() {
    const { patientId } = useParams();
    const { isOpen, onOpen, onClose } = useDisclosure();
    const [patientData, setPatientData] = useState(null);
    const [recentRecord, setRecentRecord] = useState(null);
    const [editPatient, setEditPatient] = useState(null);
    const [showHint, setShowHint] = useState(false);
    const Navigate = useNavigate();
  const [formData, setFormData] = useState({
    patientId: "",
    patientName: "",
    doctorName: "",
    ward: "",
    pastMedHis: "",
    patientAge: "",
    patientHeight: "",
    patientBloodGroup: "",
    patientSex: "",
    bed: "",
  });
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevFormData) => ({ ...prevFormData, [name]: value }));
  };

    const handleFormSubmit = async (e) => {
        e.preventDefault();
        const dataToSubmit = {
          ...formData,
          ward: formData.ward === "" ? null : formData.ward,
          bed: formData.bed === "" ? null : formData.bed,
        };
        try {
          const response = await AxiosInstance.put(
            `/patients/${formData.patientId}/`,
            dataToSubmit
          );
          if (response.status === 200) {
            fetchPatients(); // Fetch updated patient list after successful update
            alert("Patient details updated successfully");
            setEditPatient(null); // Clear edit state
          } else {
            throw new Error("Failed to update patient details");
          }
        } catch (error) {
          console.error("Error updating patient:", error);
        }
      };
    
    const handleEdit = (patient) => {
        setEditPatient(patient);
        setFormData({
            patientId: patient.patientId,
            patientName: patient.patientName,
            doctorName: patient.doctorName,
            ward: patient.ward,
            pastMedHis: patient.pastMedHis,
            patientAge: patient.patientAge,
            patientHeight: patient.patientHeight,
            patientBloodGroup: patient.patientBloodGroup,
            patientSex: patient.patientSex,
            bed: patient.bed,
        });
    };

    useEffect(() => {
        // Fetch patient information when patientId changes
        if (patientId) {
            console.log(patientId, patientId);
            AxiosInstance
                .get(`patientinfo/${patientId}/`)
                .then((response) => {
                    // Update state with fetched data
                    setPatientData(response.data.patientData);
                    setRecentRecord(response.data.recentRecord || {}); // handle both null and empty object
                    console.log(response);
                })
                .catch((error) => {
                    console.error("Error fetching patient info:", error);
                });
        }
    }, []);
    return (
        <>
            <Navbar />
            <div className="p-2 w-full">

                <Flex wrap="wrap" w="100%" direction={{ base: 'column', md: 'row' }} justifyContent="start" gap="5px" mt="3px">
                    {/* Left box for patient details */}
                    <Box h='100%'flex='1' w={{base:'100%',md:'100%'}} bg='white' borderWidth='1px' borderRadius='lg' p={2} boxShadow='md' _hover={{ boxShadow: "outline", borderColor: "blue.700", borderRadius: "5px" }}>

                        <Badge borderRadius='full' px='2' colorScheme='blue'>
                            Patient Details
                        </Badge>

                        <Flex w="100%" p={1}>
                            <div>
                                
                                <Heading size={8} mt={1} mb={1} > Patient Name: {" "}{patientData ? patientData.patientName : null}</Heading >
                                <Heading size={4} mt={1} mb={1} > Patient Id:{" "}{patientData ? patientData.patientId : null}</Heading >
                                <>
                                </>
                                {patientData ? <ul className="list-disc list-inside">
                                    {/* List items for displaying placeholder vital signs */}
                                    <li className="flex items-center">
                                        <HeartIcon className="w-5 h-5 text-red-500 mr-2" />
                                        <h1>Age:{" "}{patientData.patientAge}</h1>
                                    </li>
                                    <li className="flex items-center">
                                        <ChartBarIcon className="w-5 h-5 text-blue-500 mr-2" />
                                        <h1>Doctor Assigned:{" "}{patientData.doctorName}</h1>
                                    </li>
                                    <li className="flex items-center">
                                        <ChartBarIcon className="w-5 h-5 text-blue-500 mr-2" />
                                        <h1>Blood Group:{" "} {patientData.patientBloodGroup}</h1>
                                    </li>
                                    <li className="flex items-center">
                                        <ChartBarIcon className="w-5 h-5 text-blue-500 mr-2" />
                                        <h1>Sex: {" "}{patientData.patientSex}</h1>
                                    </li>
                                    <li className="flex items-center">
                                        <ChartBarIcon className="w-5 h-5 text-blue-500 mr-2" />
                                        <h1>Height: {" "}{patientData.patientHeight}</h1>
                                    </li>
                                    <li className="flex items-center">
                                        <ShieldCheckIcon className="w-5 h-5 text-yellow-500 mr-2" />
                                        <h1>Ward:{" "} {patientData.ward}</h1>
                                    </li>
                                    <li className="flex items-center">
                                        <FingerPrintIcon className="w-5 h-5 text-green-500 mr-2" />
                                        <h1>
                                            Bed:{" "} {patientData.bed}
                                        </h1>{" "}
                                    </li>

                                </ul> : <div className="bg-grey-100 p-3 h-1/2 w-full bold text-lg">No patient Details yet</div>
                                }

                            </div>

                        </Flex>
                        <Box>
                                    <button className="p-2 bg-blue-900 hover:bg-blue-300 text-white hover:text-blue-900 rounded-lg m-2 border-white border-r-2" onClick={onOpen}>Edit</button>
                                </Box>
                    </Box>
                    <Box flex='1' w="100%" borderWidth='1px' borderRadius='lg' bg='blue.50' ml='3px' boxShadow='md' _hover={{ boxShadow: "lg", borderColor: "blue.700", borderRadius: "5px" }} >

                        <Accordion>

                            <AccordionItem >
                                <h2>
                                    <AccordionButton _hover={{ bg: "blue.700", color: "white" }}>
                                        <Box as='span' flex='1' textAlign='left'>
                                            Last Checked Vitals
                                        </Box>
                                        <AccordionIcon />
                                    </AccordionButton>
                                </h2>
                                <AccordionPanel pb={4}>
                                    {recentRecord ?
                                        <ul className="list-disc list-inside">
                                            {/* List items for displaying placeholder vital signs */}
                                            <li className="flex items-center">
                                                <HeartIcon className="w-5 h-5 text-red-500 mr-2" />
                                                <h1>Heart Rate:{recentRecord.heartRate}</h1>
                                            </li>
                                            <li className="flex items-center">
                                                <ChartBarIcon className="w-5 h-5 text-blue-500 mr-2" />
                                                <h1>Diastolic BP:{recentRecord.diastolicBP}</h1>
                                            </li>
                                            <li className="flex items-center">
                                                <ChartBarIcon className="w-5 h-5 text-blue-500 mr-2" />
                                                <h1>Systolic BP:{recentRecord.systolicBP}</h1>
                                            </li>
                                            <li className="flex items-center">
                                                <ShieldCheckIcon className="w-5 h-5 text-yellow-500 mr-2" />
                                                <h1>Body Temperature:{recentRecord.bodyTemp}</h1>
                                            </li>
                                            <li className="flex items-center">
                                                <FingerPrintIcon className="w-5 h-5 text-green-500 mr-2" />
                                                <h1>
                                                    SpO<sub>2</sub>:{recentRecord.spo2}
                                                </h1>{" "}
                                            </li>
                                            <li className="flex items-center">
                                                <LifebuoyIcon className="w-5 h-5 text-purple-500 mr-2" />
                                                <h1>Respiratory Rate:{" "}{recentRecord.respRate}</h1>
                                            </li>
                                        </ul> : <div className="bg-grey-100 h-1/2 w-full text-lg">No recent Records</div>
                                    }

                                </AccordionPanel>
                            </AccordionItem>

                            <AccordionItem>
                                <h2>
                                    <AccordionButton _hover={{ bg: "blue.700", color: "white" }}>
                                        <Box as='span' flex='1' textAlign='left'>
                                            Previous medical history
                                        </Box>
                                        <AccordionIcon />
                                    </AccordionButton>
                                </h2>
                                <AccordionPanel pb={4}>
                                    {patientData ? patientData.pastMedHis : "No past Medical History."}
                                </AccordionPanel>
                            </AccordionItem>
                        </Accordion>

                        <Modal isOpen={isOpen} onClose={onClose}>
                            <ModalOverlay />
                            <ModalContent>
                                <ModalHeader>Modal Title</ModalHeader>
                                <ModalCloseButton />
                                <ModalBody>
                                    <form onSubmit={handleFormSubmit} className="space-y-4">
                                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                                            <div>
                                                <label
                                                    htmlFor="patientName"
                                                    className="block font-semibold text-gray-900"
                                                >
                                                    Patient Name *
                                                </label>
                                                <input
                                                    type="text"
                                                    id="patientName"
                                                    name="patientName"
                                                    value={formData.patientName}
                                                    onChange={handleInputChange}
                                                    className="mt-1 p-2 block w-full border-gray-300 rounded-md focus:ring-indigo-500 focus:border-blue-500 sm:text-sm"
                                                    placeholder="Enter Patient Name"
                                                    required
                                                />
                                            </div>
                                            <div>
                                                <label
                                                    htmlFor="patientId"
                                                    className="block font-semibold text-gray-900"
                                                >
                                                    Patient ID *
                                                </label>
                                                <div className="relative">
                                                    <input
                                                        type="text"
                                                        id="patientId"
                                                        name="patientId"
                                                        value={formData.patientId}
                                                        onChange={handleInputChange}
                                                        onFocus={() => setShowHint(true)} // Show hint on focus
                                                        onBlur={() => setShowHint(false)} // Hide hint on blur
                                                        className="mt-1 p-2 block w-full border-gray-300 rounded-md focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                                                        placeholder="Patient ID"
                                                        pattern="[0-9]{4}" // Pattern for patient ID like 0001
                                                        title="Patient ID must be in the format of 4 digits (e.g., 0001)"
                                                        required
                                                    />
                                                    {showHint && (
                                                        <small className="absolute inset-y-0 right-0 pr-3 flex items-center text-gray-400">
                                                            Format: XXXX
                                                        </small>
                                                    )}
                                                </div>
                                            </div>
                                            <div>
                                                <label
                                                    htmlFor="doctorName"
                                                    className="block font-semibold text-gray-900"
                                                >
                                                    Doctor Name *
                                                </label>
                                                <input
                                                    type="text"
                                                    id="doctorName"
                                                    name="doctorName"
                                                    value={formData.doctorName}
                                                    onChange={handleInputChange}
                                                    className="mt-1 p-2 block w-full border-gray-300 rounded-md focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                                                    placeholder="Enter Doctor Name"
                                                    required
                                                />
                                            </div>
                                            <div>
                                                <label
                                                    htmlFor="ward"
                                                    className="block font-semibold text-gray-900"
                                                >
                                                    Ward
                                                </label>
                                                <select
                                                    id="ward"
                                                    name="ward"
                                                    value={formData.ward}
                                                    onChange={handleInputChange}
                                                    className="mt-1 p-2 block w-full border-gray-300 rounded-md focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                                                >
                                                    <option value="">--Select Ward--</option>
                                                    <option value="Tc1">Tc1</option>
                                                    <option value="Tc2">Tc2</option>
                                                    <option value="Tc3">Tc3</option>
                                                </select>
                                            </div>
                                            <div>
                                                <label
                                                    htmlFor="pastMedHis"
                                                    className="block font-semibold text-gray-900"
                                                >
                                                    Past Medical History *
                                                </label>
                                                <input
                                                    type="text"
                                                    id="pastMedHis"
                                                    name="pastMedHis"
                                                    value={formData.pastMedHis}
                                                    onChange={handleInputChange}
                                                    className="mt-1 p-2 block w-full border-gray-300 rounded-md focus:ring-blue-600 focus:border-blue-600 sm:text-sm"
                                                    placeholder="Enter Past Medical History"
                                                    required
                                                />
                                            </div>
                                            <div>
                                                <label
                                                    htmlFor="patientAge"
                                                    className="block font-semibold text-gray-900"
                                                >
                                                    Patient Age *
                                                </label>
                                                <input
                                                    type="number"
                                                    id="patientAge"
                                                    name="patientAge"
                                                    value={formData.patientAge}
                                                    onChange={handleInputChange}
                                                    className="mt-1 p-2 block w-full border-gray-300 rounded-md focus:ring-blue-600 focus:border-blue-600 sm:text-sm"
                                                    placeholder="Enter Patient Age"
                                                    required
                                                />
                                            </div>
                                            <div>
                                                <label
                                                    htmlFor="patientHeight"
                                                    className="block font-semibold text-gray-900"
                                                >
                                                    Patient Height (cm) *
                                                </label>
                                                <input
                                                    type="number"
                                                    id="patientHeight"
                                                    name="patientHeight"
                                                    value={formData.patientHeight}
                                                    onChange={handleInputChange}
                                                    className="mt-1 p-2 block w-full border-gray-300 rounded-md focus:ring-blue-600 focus:border-blue-600 sm:text-sm"
                                                    placeholder="Enter Patient Height"
                                                    required
                                                />
                                            </div>
                                            <div>
                                                <label
                                                    htmlFor="patientBloodGroup"
                                                    className="block font-semibold text-gray-900"
                                                >
                                                    Patient Blood Group *
                                                </label>
                                                <select
                                                    id="patientBloodGroup"
                                                    name="patientBloodGroup"
                                                    value={formData.patientBloodGroup}
                                                    onChange={handleInputChange}
                                                    className="mt-1 block w-full border-gray-300 rounded-md focus:ring-blue-600 focus:border-blue-600 sm:text-sm"
                                                    required
                                                >
                                                    <option value="">Select Patient Blood Group</option>
                                                    <option value="O+">O+</option>
                                                    <option value="O-">O-</option>
                                                    <option value="A+">A+</option>
                                                    <option value="A-">A-</option>
                                                    <option value="B+">B+</option>
                                                    <option value="B-">B-</option>
                                                    <option value="AB+">AB+</option>
                                                    <option value="AB-">AB-</option>
                                                </select>
                                            </div>
                                            <div>
                                                <label
                                                    htmlFor="patientSex"
                                                    className="block font-semibold text-gray-900"
                                                >
                                                    Patient Sex *
                                                </label>
                                                <select
                                                    id="patientSex"
                                                    name="patientSex"
                                                    value={formData.patientSex}
                                                    onChange={handleInputChange}
                                                    className="mt-1 block w-full border-gray-300 rounded-md focus:ring-blue-600 focus:border-blue-600 sm:text-sm"
                                                    required
                                                >
                                                    <option value="">Select Patient Sex</option>
                                                    <option value="Male">Male</option>
                                                    <option value="Female">Female</option>
                                                    <option value="Other">Other</option>
                                                </select>
                                            </div>
                                            <div>
                                                <label
                                                    htmlFor="bed"
                                                    className="block font-semibold text-gray-900"
                                                >
                                                    Bed
                                                </label>
                                                <input
                                                    type="text"
                                                    id="bed"
                                                    name="bed"
                                                    value={formData.bed}
                                                    onChange={handleInputChange}
                                                    className="mt-1 p-2 block w-full border-gray-300 rounded-md focus:ring-blue-600 focus:border-blue-600 sm:text-sm"
                                                    placeholder="Enter Bed Number"

                                                />
                                            </div>
                                        </div>
                                        <div className="flex justify-end space-x-4 mt-4">
                                            <button
                                                type="submit"
                                                className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500"
                                                onClick={onClose}
                                            >
                                                Update
                                            </button>
                                            <button
                                                type="button"
                                                onClick={() => {setEditPatient(null)
                                                    onClose()
                                                }
                                                }
                                                className="px-4 py-2 bg-gray-600 text-white rounded-md hover:bg-gray-700 focus:outline-none focus:ring-2 focus:ring-gray-500"
                                            >
                                                Cancel
                                            </button>
                                        </div>
                                    </form>
                                </ModalBody>

                                
                            </ModalContent>
                        </Modal>
                        <button className="p-2 bg-blue-900 hover:bg-blue-300 text-white hover:text-blue-900 rounded-lg m-2 border-white border-r-2" onClick={() => {
                            Navigate('/patientvitals');
                        }}>Vitals</button>
                    </Box>
                </Flex>
                <Flex w="100%" mt="10px" h="80%" >
                    <Tabular patientId={patientId} />
                </Flex>


            </div>
        </>
    )
}