import React, { useState } from "react";
import {
  BrowserRouter as Router,
  Route,
  Routes,
  Navigate,
} from "react-router-dom"; // Importing necessary components from react-router-dom
import Signup from "./components/auth/Signup"; // Importing Signup component
import Home from "./components/Home/Home"; // Importing Home component
import Patients from "./components/Patients/Patients"; // Importing Patients component
import Dataentry from "./components/VitalsEntry/Dataentry"; // Importing Dataentry component
import Login from "./components/auth/Login"; // Importing Login component
import { AuthProvider } from "../Auth_contxt/Authcontext"; // Importing AuthProvider from Authcontext
import PrivateRoute from "../utils/PrivateRoute"; // Importing PrivateRoute component
import PatientRecordsTab from "./components/Patient-Records/PatientRecordsTab"; // Importing PatientRecordsTab component
import Disease_page from "./components/Disease-Summary/Disease_page"; // Importing Disease_page component
import PasswordResetConfirm from "./components/auth/PasswordResetConfirm"; // Importing PasswordResetConfirm component
import PasswordResetRequest from "./components/auth/PasswordRequest"; // Importing PasswordResetRequest component
import Profilespec from "./components/ProfileUser/ImageSpec"; // Importing Profilespec component
import OTP from "./components/auth/OTP";
import PatientProfile from "./components/PatientProfile";
import PatientProfilePage from "./components/PatientProfilePage";
import NewLogin from "./components/NewLogin";
import DoctorProfilePage from "./components/DoctorProfilePage";
const App = () => {
  const [username, setUsername] = useState(""); // State for username input
  const [password, setPassword] = useState(""); // State for password input
  const [role, setRole] = useState("");
  const [email, setEmail] = useState(""); // State for password input
  const [otp, setOtp] = useState(""); // State for password input
  return (
    <Router>
      {/* Setting up the router component */}
      <AuthProvider>
        {/* Providing authentication context with AuthProvider */}
        <Routes>
          {/* Defining routes within the application */}
          {/* Public routes */}
          <Route
            path="/password_reset"
            element={<PasswordResetRequest />}
          />
          <Route
            path="/patient_profile/:patientId"
            element={<PatientProfilePage />}
          />
          {/* Route for password reset request */}
          <Route
            path="/reset/:username/:token"
            element={<PasswordResetConfirm />}
          />{" "}
           <Route path="/new" element={<NewLogin />} />
          <Route path="/register" element={<Signup username={username} setUsername={setUsername} password={password} setPassword={setPassword} setOtp={setOtp} email={email} setEmail={setEmail} role={role} setRole={setRole}
          />} />{" "}
          <Route path="/otp" element={<OTP role={role} username={username} password={password} otp={otp} email={email} setOtp={setOtp}/>} />{" "}
          {/* Route for password reset confirmation */}
          <Route path="/" element={<Navigate to="/home" />} />{" "}
          {/* Default route redirects to Home */}
          <Route path="/home" element={<Home />} />{" "}
          {/* Route for Home component */}

          {/* Route for Signup component */}
          <Route path="/login" element={<Login />} />{" "}
          {/* Route for Login component */}
          <Route path="/profile/:username" element={<Profilespec />} />{" "}
          {/* Route for Profilespec component */}
          {/* Private routes (requires authentication) */}
          <Route
            path="/patients"
            element={
              <Patients />
            }
          />
          {/* Patient profile Page */}
          <Route
            path="/patient/:patientId"
            element={<PatientProfile />}
          />
          <Route
            path="/disease_summary/:patientId"
            element={
          
                <Disease_page /> 
            }
          />
          <Route
            path="/PRecords"
            element={<PatientRecordsTab /> } // all recrods of patient entries 
          />
          <Route
            path="/patientvitals"
            element={<Dataentry />}
          />
          <Route
            path="/doctor_profile/:doctor"
            element={<DoctorProfilePage />}
          />
        </Routes>
      </AuthProvider>
    </Router>
  );
};

export default App;
